﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Shopping.DataAccess.Data;
using Shopping.Models;

namespace ShoppingWeb.Areas.user.Controllers
{
    public class ProductController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ProductController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, ApplicationDbContext db, SignInManager<ApplicationUser> signInManager, IWebHostEnvironment webHostEnvironment)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _db = db;
            _signInManager = signInManager;
            _webHostEnvironment = webHostEnvironment;
        }



        [HttpGet]
        public async Task<IActionResult> Index()
        {
            ViewBag.Roledata = HttpContext.Session.GetString("Role");
            var UserId = HttpContext.Session.GetString("Uid");
            IEnumerable<ProductVM> data;

            //var pro=_db.product.Where(x=>x.DealerId==UserId).ToList();
            //var data = (from pra in pro join 
            //           dis in _db.discounttable
            //           on pra.ProductId equals dis.ProductId into jointable
            //           from resultdata in jointable.DefaultIfEmpty()                       
            //           select (new ProductVM
            //           {
            //            ProductId = pra.ProductId,
            //            ProductName = pra.ProductName,
            //            ProductDescription = pra.ProductDescription,
            //            Price = pra.Price,
            //            Quantity = pra.Quantity, 
            //            Discount = resultdata == null ? 0 : resultdata.Discount
            //           })
            //           ).ToList();


            data = (from PR in _db.product
                    where PR.DealerId == UserId
                    let AD = _db.discounttable
                    .Where(x => x.ProductId == PR.ProductId).OrderBy(x => x.DiscountId).LastOrDefault()
                    select (new ProductVM
                    {
                        ProductId = PR.ProductId,
                        ProductName = PR.ProductName,
                        ProductDescription = PR.ProductDescription,
                        IsActive = PR.IsActive,
                        Price = PR.Price,
                        Quantity = PR.Quantity,
                        Discount = AD.Discount == null ? 0 : AD.Discount
                    })
                    ).ToList();

            return View(data);
        }


        [HttpGet]
        public async Task<IActionResult> Upsert(int? Id)
        {
            if (Id == null)
            {
                Product model = new Product();
                return View(model);
            }
            var data = _db.product.Find(Id);
            return View(data);
        }

        [HttpPost]
        public async Task<IActionResult> Upsert(int? Id, Product obj, IFormFile File)
        {

            try
            {
                var UserId = HttpContext.Session.GetString("Uid");

                string wwwRootPath = _webHostEnvironment.WebRootPath;

                if (File != null)
                {
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(File.FileName);
                    string productpath = Path.Combine(wwwRootPath, @"images\products");

                    if (!string.IsNullOrEmpty(obj.ImageUrl))
                    {
                        //Delete Old Image
                        var oldimagepath = Path.Combine(wwwRootPath, obj.ImageUrl.TrimStart('\\'));

                        if (System.IO.File.Exists(oldimagepath))
                        {
                            System.IO.File.Delete(oldimagepath);
                        }
                    }

                    using (var filestream = new FileStream(Path.Combine(productpath, fileName), FileMode.Create))
                    {
                        File.CopyTo(filestream);
                    }
                    obj.ImageUrl = @"\images\products\" + fileName;

                }


                if (Id == 0 || Id == null)
                {

                    var data = new Product()
                    {
                        ProductName = obj.ProductName,
                        ProductDescription = obj.ProductDescription,
                        IsActive = true,
                        Price = obj.Price,
                        Quantity = obj.Quantity,
                        DealerId = UserId,
                        ImageUrl = obj.ImageUrl                      
                    };

                    await _db.product.AddAsync(data);
                    await _db.SaveChangesAsync();
                    TempData["success"] = "Product Added Successfully";
                }
                else
                {
                    var data = new Product()
                    {
                        ProductId = Id.Value,
                        ProductName = obj.ProductName,
                        ProductDescription = obj.ProductDescription,
                        IsActive= obj.IsActive,
                        Price = obj.Price,
                        Quantity = obj.Quantity,
                        DealerId = UserId,
                        ImageUrl = obj.ImageUrl
                    };

                    _db.product.Update(data);
                    await _db.SaveChangesAsync();
                    TempData["success"] = "Product Updated Successfully";
                }

                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<IActionResult> Status(int Id)
        {
            if (Id != null)
            {
                var data = _db.product.Find(Id);
                if (data.IsActive == true)
                {
                    data.IsActive = false;
                }
                else
                {
                    data.IsActive = true;
                }
                _db.product.Update(data);
                _db.SaveChanges();
            }  
            return RedirectToAction("Index","Product");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProduct(int Id)
        {
            var DelPro = _db.product.Find(Id);
            if (DelPro != null)
            {

            }
            var oldimagepath = Path.Combine(_webHostEnvironment.WebRootPath, DelPro.ImageUrl.TrimStart('\\'));
            if (System.IO.File.Exists(oldimagepath))
            {
                System.IO.File.Delete(oldimagepath);
            }
            _db.product.Remove(DelPro);
            _db.SaveChanges();
            TempData["success"] = "Product Delete Successfully";
            return RedirectToAction("Index", "Product");
        }

        [HttpGet]
        public async Task<IActionResult> Discount(int id)
        {
            var data = _db.product.Find(id);
            DiscountTable obj = new DiscountTable()
            {
                ProductName = data.ProductName,
                Price = data.Price,
                ProductId = data.ProductId,
            };
            return View(obj);
        }

        [HttpPost]
        public async Task<IActionResult> Discount(DiscountTable obj)
        {
            if (obj.DiscountType == 0)
            {
                obj.Discount = obj.Discount;
            }
            else
            {
                obj.Discount = (obj.Price * obj.Discount) / 100;
            }

            await _db.discounttable.AddAsync(obj);
            await _db.SaveChangesAsync();
            TempData["success"] = "Discount Added Successfully";
            return RedirectToAction("Index","Product");
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            HttpContext.Session.Clear();
            var username = User.Identity.Name;
            return RedirectToAction("Index", "Home");
        }

    }
}
