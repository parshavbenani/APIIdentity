﻿using MailKit.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MimeKit.Text;
using MimeKit;
using Shopping.DataAccess.Data;
using Shopping.Models;
using System.Dynamic;
using MailKit.Net.Smtp;

namespace ShoppingWeb.Areas.user.Controllers
{
    public class HomeController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HomeController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, ApplicationDbContext db, SignInManager<ApplicationUser> signInManager, IWebHostEnvironment webHostEnvironment)
        {         
            _userManager = userManager;
            _roleManager = roleManager;
            _db = db;
            _signInManager = signInManager;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(LoginVM obj)
        {
            try
            {
                
                    var data = await _userManager.FindByEmailAsync(obj.Email);
                    if (data != null)
                    {
                        if (data.IsActive == true)
                        {
                            var result = await _signInManager.PasswordSignInAsync(data, obj.Password, false, false);
                            var role = await _userManager.GetRolesAsync(data);
                            var currentrole = role.FirstOrDefault();

                            var Uid = await _userManager.GetUserIdAsync(data);

                            HttpContext.Session.SetString("Role", currentrole);
                            HttpContext.Session.SetString("Uid", Uid);


                            if (result.Succeeded && role.Any())
                            {
                                if (currentrole == "Dealer")
                                {
                                    return RedirectToAction("Index", "Product");
                                }
                                return RedirectToAction("Dashboard");
                            }
                            else
                            {

                                await _signInManager.SignOutAsync();   // for session role clear for the _layout/logout btn
                                HttpContext.Session.Clear();
                            }
                        }
                    }        
                TempData["error"] = "Something is wrong Please Check Your Email & Password";
                return View();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<IActionResult> SignUp()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SignUp(AdminAndDealerVM obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ApplicationUser applicationUser = new ApplicationUser()
                    {
                        UserName = obj.UserName,
                        Name = obj.Name,
                        Email = obj.Email,
                        PhoneNumber = obj.PhoneNumber,
                        City = obj.City,
                        State = obj.State,
                        StreetAddress = obj.StreetAddress,
                        PostalCode = obj.PostalCode.ToString(),
                        status = Globle.Pending

                    };

                    await _userManager.CreateAsync(applicationUser, obj.Password);

                    await _userManager.AddToRoleAsync(applicationUser, RoleType.Dealer.ToString());

                    TempData["success"] = "Registration Successfully";
                    return RedirectToAction("Index");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return View();
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            HttpContext.Session.Clear();
            var username = User.Identity.Name;
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return NotFound();
            }

            ViewBag.Roledata = HttpContext.Session.GetString("Role");

            dynamic myModel = new ExpandoObject();
            myModel.pro = await _db.product.ToListAsync();

            var role = HttpContext.Session.GetString("Role");
            switch (role)
            {
                case "SuperAdmin":
                    IEnumerable<DashboardVM> applicationUsers;
                    applicationUsers = (from AU in _db.applicationUsers
                                        join UR in _db.UserRoles
                                        on AU.Id equals UR.UserId
                                        join RL in _db.Roles
                                        on UR.RoleId equals RL.Id
                                        where RL.Name != "SuperAdmin"
                                        select (new DashboardVM
                                        {
                                            UserName = AU.UserName,
                                            Email = AU.Email,
                                            State = AU.State,
                                            Role = RL.Name,
                                            Id = AU.Id,
                                            Status = AU.status.ToString()
                                        })
                                        );
                    return View(applicationUsers);
                case "Admin":
                    IEnumerable<DashboardVM> applicationUsers1;
                    applicationUsers1 = (from AU in _db.applicationUsers
                                         join UR in _db.UserRoles
                                         on AU.Id equals UR.UserId
                                         join RL in _db.Roles
                                         on UR.RoleId equals RL.Id
                                         where RL.Name != "Admin" && RL.Name != "SuperAdmin"
                                         select (new DashboardVM
                                         {
                                             UserName = AU.UserName,
                                             Email = AU.Email,
                                             State = AU.State,
                                             Role = RL.Name,
                                             Id = AU.Id,
                                             Status = AU.status.ToString()
                                         })
                                            );
                    return View(applicationUsers1);
                case "Dealer":

                    return RedirectToAction("Product");
                    //var UserId = HttpContext.Session.GetString("Uid"); 

                    //myModel.pro = _db.product.Where(x => x.DealerId == UserId).ToList();

                    ////if (id != 0)
                    ////{
                    ////    myModel.dispro = _db.discounttable.LastOrDefault(x => x.ProductId == id);
                    ////}
                    ////else
                    ////{
                    ////    myModel.dispro = _db.discounttable.ToList();

                    ////}

                    //myModel.dispro = _db.discounttable.ToList();
                    //var obj = new List<DiscountTable>();
                    //obj = myModel.dispro;
                    //var item = from s in obj select s.ProductId;
                    //foreach (var items in obj)
                    //{
                    //    var Adddata = _db.product.Where(x => x.ProductId == items.ProductId).OrderBy(x=>x.ProductId == items.ProductId).LastOrDefault();                       
                    //}

                    //return View(myModel);
            }

            return View();
        }



        [HttpGet]
        public async Task<IActionResult> AdminRegistration()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> AdminRegistration(AdminAndDealerVM obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ApplicationUser applicationUser = new ApplicationUser()
                    {
                        UserName = obj.UserName,
                        Name = obj.Name,
                        Email = obj.Email,
                        PhoneNumber = obj.PhoneNumber,
                        City = obj.City,
                        State = obj.State,
                        StreetAddress = obj.StreetAddress,
                        PostalCode = obj.PostalCode.ToString(),
                        status = Globle.Approve,
                        IsActive = true

                    };

                    await _userManager.CreateAsync(applicationUser, obj.Password);

                    await _userManager.AddToRoleAsync(applicationUser, RoleType.Admin.ToString());

                    TempData["success"] = "Admin Added Successfully";
                    return RedirectToAction("Dashboard");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> AddRole()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddRole(RoleVM obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!_roleManager.RoleExistsAsync(obj.RName).GetAwaiter().GetResult())
                    {
                        await _roleManager.CreateAsync(new IdentityRole(obj.RName));
                        TempData["success"] = "Role Added Successfully";
                        return RedirectToAction("Dashboard");
                    }
                    return View();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return View();
        }


        public async Task<IActionResult> CApprove(string id)
        {

            var data = await _userManager.FindByIdAsync(id);

            if (data.status == Globle.Pending)
            {
                data.status = Globle.Approve;
                data.IsActive = true;
                _db.SaveChanges();

                string FromMail = "parshav312@gmail.com";
                string FromPassword = "ppjcfxmhxpwhvysz";

                var message = new MimeMessage();
                message.From.Add(MailboxAddress.Parse(FromMail));
                message.To.Add(MailboxAddress.Parse(data.Email));
                message.Subject = "Test";
                message.Body = new TextPart(TextFormat.Html) { Text = "Your request has been approved successfully..." };

                using (var client = new SmtpClient())
                {
                    client.Connect("smtp.gmail.com", 587, SecureSocketOptions.StartTls);
                    client.Authenticate(FromMail, FromPassword);
                    client.Send(message);
                    client.Disconnect(true);
                }
            }
            TempData["success"] = "Request Approved Successfully";
            return RedirectToAction("Dashboard", "Home");
        }

        [HttpPost]
        public async Task<IActionResult> CReject(string? id, string? reason)
        {
            var data = await _userManager.FindByIdAsync(id);
            ViewBag.Id = id;
            if (data.status == Globle.Pending)
            {
                data.status = Globle.Reject;
                _db.SaveChanges();
            }

            string FromMail = "parshav312@gmail.com";
            string FromPassword = "ppjcfxmhxpwhvysz";

            var message = new MimeMessage();
            message.From.Add(MailboxAddress.Parse(FromMail));
            message.To.Add(MailboxAddress.Parse(data.Email));
            message.Subject = "Test";
            message.Body = new TextPart(TextFormat.Html) { Text = "Your request has been Rejected..." + reason };

            using (var client = new SmtpClient())
            {
                client.Connect("smtp.gmail.com", 587, SecureSocketOptions.StartTls);
                client.Authenticate(FromMail, FromPassword);
                client.Send(message);
                client.Disconnect(true);
            }

            TempData["success"] = "Request rejected Successfully";
            return RedirectToAction("Dashboard", "Home");
        }

        public async Task<IActionResult> CBlock(string id)
        {
            var data = await _userManager.FindByIdAsync(id);
            if (data.IsActive == true)
            {
                data.IsActive = false;
                data.status = Globle.Block;
                _db.SaveChanges();
            }
            TempData["success"] = "User Block Successfully";
            return RedirectToAction("Dashboard");
        }

        public async Task<IActionResult> CUnblock(string id)
        {
            var data = await _userManager.FindByIdAsync(id);
            if (data.IsActive == false)
            {
                data.IsActive = true;
                data.status = Globle.Approve;
                _db.SaveChanges();
            }
            TempData["success"] = "User Unblock Successfully";
            return RedirectToAction("Dashboard");
        }

        [HttpGet]
        public async Task<IActionResult> ViewProduct(string Id)
        {
            //  IEnumerable<Product> data = _db.product.Where(x => x.DealerId == Id.ToString());

            var data = (from PR in _db.product
                        where PR.DealerId == Id
                        let AD = _db.discounttable
                        .Where(x => x.ProductId == PR.ProductId).OrderBy(x => x.DiscountId).LastOrDefault()
                        select (new ProductVM
                        {
                            ProductId = PR.ProductId,
                            ProductName = PR.ProductName,
                            ProductDescription = PR.ProductDescription,
                            ImageUrl = PR.ImageUrl,
                            Price = PR.Price,
                            Quantity = PR.Quantity,
                            Discount = AD.Discount == null ? 0 : AD.Discount
                        })
                    ).ToList();

            return View(data);
        }


       












        public async Task<IActionResult> Privacy()
        {
            //ApplicationUser applicationUser = new ApplicationUser()
            //{
            //    UserName = "Parshav",
            //    Email = "Parshav@gmail.com",
            //    //  PasswordHash = "Par123",
            //    Name = "Parshav",
            //    EmailConfirmed = false,
            //    PhoneNumber = "9876543210",
            //    State = "Gujarat",
            //    LockoutEnabled = false,
            //    PostalCode = "380001",
            //    SecurityStamp = "7jfehfefnkwndjgrkvjedfnef",
            //    ConcurrencyStamp = "ythrhtg-ewewbfhbt-sgrwgrgrg-6524-mkrgmrk",
            //    City = "Ahmedabad",
            //    status = Globle.Approve,
            //    IsActive = true
            //};
            //await _userManager.CreateAsync(applicationUser, applicationUser.PasswordHash = "Parshav123@");

            //if (_roleManager.RoleExistsAsync("SuperAdmin").GetAwaiter().GetResult())
            //{
            //    IdentityResult result = await _userManager.AddToRoleAsync(applicationUser, "SuperAdmin");
            //}

            return View();
        }
    }
}
