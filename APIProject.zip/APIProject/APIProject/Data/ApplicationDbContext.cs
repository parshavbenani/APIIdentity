﻿using APIProject.Model;
using Microsoft.EntityFrameworkCore;

namespace APIProject.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Register> registers { get; set; }

    }
}
