﻿using APIProject.Data;
using APIProject.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace APIProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public UserController(ApplicationDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        [Route("AllUser/")]
        public IActionResult AllUser()
        {          
            return Ok(_db.registers.ToList());
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Registration/")]
        public IActionResult UserRegistration(Register user)
        {

            _db.registers.Add(user);
            _db.SaveChanges();

            return Ok(user);
        }


        [AllowAnonymous]
        [HttpPost]
        [Route("Login/")]
        public IActionResult Login(Register user) 
        { 
            var check = _db.registers.Where(x => x.UserName == user.UserName && x.Password == user.Password).FirstOrDefault();

            if (check == null)
            {
                return BadRequest("Invalid UserName And Password");
            }
            else
            {
                var tokenhandler = new JwtSecurityTokenHandler();
                var Key = Encoding.ASCII.GetBytes("Hello GoodAfterNoon");
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[] { new Claim("id", user.UserName) }),
                    Expires = DateTime.UtcNow.AddDays(1),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Key), SecurityAlgorithms.HmacSha512Signature)
                };
                var token = tokenhandler.CreateToken(tokenDescriptor);
                var encrypterToken = tokenhandler.WriteToken(token);

                return Ok(new { token = encrypterToken, UserName = check.UserName, Password = check.Password });
            }


        }

    }
}
