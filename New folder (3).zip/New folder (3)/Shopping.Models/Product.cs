﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        public string ProductName { get; set;}
        public string ProductDescription { get; set;}
        public bool IsActive { get; set;}
        
        [DisplayName("Image")]
        [Required(ErrorMessage = "Please import Image")]
        public string? ImageUrl { get; set;}
        [Required]
        [Range(1, 100000)]
        public double Price { get; set; }
        [Required]
        [Range(1, 10000)]
        public int Quantity { get; set; }
        public string DealerId  { get; set; }


    }
}
